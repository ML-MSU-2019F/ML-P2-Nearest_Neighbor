from abc import ABC, abstractmethod
from Algorithm import Algorithm
# The base class that lets us know what we can expect from a Nearest Neighbor Algorithm
class NearestNeighbor(Algorithm):
    #constructor
    def __init__(self):
        pass
    def getNearestNeighbor(self,data_line,regression):
        pass
    def classify(self):
        pass
    def regress(self):
        pass



